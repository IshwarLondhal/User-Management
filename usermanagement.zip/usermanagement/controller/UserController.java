package com.exp.usermanagement.controller;

import java.util.Scanner;

import com.exp.usermanagement.serviceimpl.UserServiceImpl;

import com.exp.usermanagement.service.UserService;

public class UserController {
	public static void main(String[] args) {
		System.err.println("******* Welcome to Our User System ********");
		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		UserService us = new UserServiceImpl();

		while (flag) {

			System.out.println("1 : for add Users");
			System.out.println("2 : for display single User");
			System.out.println("3 : for display all users");
			System.out.println("4 : for update User details");
			System.out.println("5 : for delete User details");
			System.out.println("6 : EXIT");
			System.out.println("Enter your choise");

			int ch = ValidChoise();

			switch (ch) {

			case 1:
				us.userAdd();
				break;

			case 2:
				us.displaySingleUser();
				break;

			case 3:
				us.displayAllUser();
				break;

			case 4:
				us.updateUserDetails();
				break;

			case 5:
				us.deleteUserDetails();
				break;

			case 6:
				flag = false;
				break;

			default:
				System.out.println("Entered choise is invalid please enter valid choise between 1 to 6");

			}
		}

	}
	public static int ValidChoise() {
		Scanner sc = new Scanner(System.in);
		int vc;
		try {
			 vc = sc.nextInt();
			 return vc;
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Invalid input type please enter interger value");
			return ValidChoise();
		}
	}
}
