package com.exp.usermanagement.serviceimpl;

import com.exp.usermanagement.service.UserService;
import com.exp.usermanagement.validations.UserValidations;

import java.util.Scanner;

import com.exp.usermanagement.model.User;

public class UserServiceImpl implements UserService{
	User us = new User();
	User u[] = new User[5];
	Scanner sc = new Scanner(System.in);

	@Override
	public void userAdd() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter how many users you want to add");
		int n = ValidAddUserChoise();
		for (int i=0; i<n; i++) {
			User user = new User();
			System.out.println("Enter User Id :");
			user.setUid(ValidUserId());
//			System.out.println("Enter User name : ");
			String uname = UserValidations.validateUserAccountName();
			user.setUname(uname);
//			System.out.println("Enter User Mail Id : ");
			String mailid = UserValidations.validateUserAccountMailid();
			user.setMailid(mailid);
			System.out.println("Enter User Address");
			user.setUaddress(sc.next());
			System.out.println("Enter User Salary");
			user.setUsalary(ValidUserSalary());
			System.out.println("Enter User Gender");
			user.setUsergender(sc.next());
			long mobileno = UserValidations.validateUserAccountContactno();
			user.setUserno(mobileno);
			int pin = UserValidations.validateUserAccountPIN();
			user.setPin(pin);
			
			u[i] = user;
			System.out.println("User added Sucessful....");
		}
		
	}

	@Override
	public void displayAllUser() {
//		System.out.println("Display all user details.....");
		for (User user : u) {
			if(user != null ) {
			System.out.println(user);
			}
		}
		
	}

	@Override
	public void displaySingleUser() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter User Id");
		int id = ValidUserId();
		for (User user : u) {
			if(user != null && user.getUid() == id ) {
				System.out.println(user);
			}
		}
		
	}

	@Override
	public void updateUserDetails() {
		System.out.println("Enter your User Id");
		int idno = ValidUserId();
		for (User user : u) {
			
		
		if(user.getUid() == idno) {
			boolean b = true;
			while(b) {
			System.out.println("1 :Update your Name");
			System.out.println("2 :Update your Contact number");	
			System.out.println("3 :Update your mail id");
			System.out.println("4 :Exit");
			System.out.println("Enter choise what you want to update from your Info...");
			int choise = ValidUserId();
			switch(choise) {
			case 1:
				String uname = UserValidations.validateUserAccountName();
				user.setUname(uname);
				break;
			case 2:
				long mobileno = UserValidations.validateUserAccountContactno();
				user.setUserno(mobileno);
				break;
			case 3:
				String mailid = UserValidations.validateUserAccountMailid();
				user.setMailid(mailid);
				break;
			case 4:
				b=false;
				break;
			default:
				System.out.println("invalid choise plese enter valid choise...");
				break;
				
			}
			}
			
			System.out.println("User Info Updated Sucessful...");
		}else {
			System.out.println("User  doesn't exist...");
		}
		}
		
	}

	@Override
	public void deleteUserDetails() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter User Id");
		int index=0;
		int id = ValidUserId();
		for (int i=0; i<u.length; i++) {
			if(u[i] != null && u[i].getUid() == id ) {
				index = i;
				break;
			}
		}
		u[index]=null;
		System.out.println("User Info Deleted....");
		
	}
	public static int ValidAddUserChoise() {
		Scanner sc = new Scanner(System.in);
		int au;
		try {
			 au = sc.nextInt();
			 return au;
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Invalid input type please enter interger value");
			return ValidAddUserChoise();
		}
	}
	public static int ValidUserId() {
		Scanner sc = new Scanner(System.in);
		int au;
		try {
			 au = sc.nextInt();
			 return au;
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Invalid input type please enter interger value");
			return ValidUserId();
		}
	}
	public static Double ValidUserSalary() {
		Scanner sc = new Scanner(System.in);
		double salary;
		try {
			 salary = sc.nextDouble();
			 return salary;
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Invalid input type please enter interger value");
			return ValidUserSalary();
		}
	}

}
