package com.exp.usermanagement.service;

public interface UserService {
	public void userAdd();
	
	public void displayAllUser();
	
	public void displaySingleUser();
	
	public void updateUserDetails();
	
	public void deleteUserDetails();

}
