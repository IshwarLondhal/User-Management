package com.exp.usermanagement.validations;

import java.util.Scanner;
import java.util.regex.Pattern;

public class UserValidations {

	public static String validateUserAccountName() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter User name :");
		String name = sc.nextLine();
		boolean flag = true;

		if (Pattern.matches("[a-zA-Z]+", name)) {
			flag = false;
//			System.out.println("valid");
		} else {
			System.out.println("Invalid");
			return validateUserAccountName();
		}
		return name;
	}

	public static long validateUserAccountAadhar() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Aadhar number ");
		long Aadhar = sc.nextLong();
		String aadhar = Long.toString(Aadhar);
//		char[] ch = aadhar.toCharArray();
//		boolean flag = true;
		if (Pattern.matches("[0-9]{12}+", aadhar)) {
			return Aadhar;
		} else {
			System.out.println("Invalid Input");
//			sc.close();
			return validateUserAccountAadhar();
		}
//		sc.close();

	}

	public static String validateUserPancard() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Pancard number...");
		String pan = sc.next();
//		char[] ch = pan.toCharArray();

		if (Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", pan)) {

			return pan;
		} else {
			System.out.println("Invalid Input");
			return validateUserPancard();
		}

	}

	public static String validateUserAccountMailid() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Mail Id");
		String mailid = sc.next();
//		char[] ch = mailid.toCharArray();

		if (Pattern.matches("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$", mailid)) {
			return mailid;
		} else {
			System.out.println("Invalid Input");
			return validateUserAccountMailid();
		}

	}

	public static long validateUserAccountContactno() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your Contact number");
//		boolean flag = true;
		long contact = sc.nextLong();
		String Contact1 = Long.toString(contact);
		if (Pattern.matches("[0-9]{10}+", Contact1)) {
//			flag = false;
			return contact;
		} else {
			System.out.println("Invalid Input");
			return validateUserAccountContactno();
		}

	}

	public static int validateUserAccountPIN() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your PIN code : ");
//		boolean flag = true;
		int pin = sc.nextInt();
		String pin1 = Long.toString(pin);
		if (Pattern.matches("[0-9]{6}+", pin1)) {
//			flag = false;
			return pin;
		} else {
			System.out.println("Invalid Input");
			return validateUserAccountPIN();
		}

	}

}
